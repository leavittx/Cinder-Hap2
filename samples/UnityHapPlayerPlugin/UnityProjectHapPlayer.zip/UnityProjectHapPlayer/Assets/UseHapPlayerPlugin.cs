﻿// on OpenGL ES there is no way to query texture extents from native texture id
#if (UNITY_IPHONE || UNITY_ANDROID) && !UNITY_EDITOR
#define UNITY_GLES_RENDERER
#endif


using UnityEngine;
using System;
using System.Collections;
using System.Runtime.InteropServices;


public class UseHapPlayerPlugin : MonoBehaviour
{
    // Native plugin rendering events are only called if a plugin is used
    // by some script. This means we have to DllImport at least
    // one function in some active script.
    // For this example, we'll call into plugin's SetTimeFromUnity
    // function and pass the current time so the plugin can animate.

#if UNITY_IPHONE && !UNITY_EDITOR
	[DllImport ("__Internal")]
#else
    [DllImport("UnityHapPlayerPlugin")]
#endif
    private static extern void SetTimeFromUnity(float t);

#if UNITY_IPHONE && !UNITY_EDITOR
	[DllImport ("__Internal")]
#else
    [DllImport("UnityHapPlayerPlugin")]
#endif
    private static extern bool HapMovieLoadFromUnity([MarshalAs(UnmanagedType.LPStr)] string path);

#if UNITY_IPHONE && !UNITY_EDITOR
	[DllImport ("__Internal")]
#else
    [DllImport("UnityHapPlayerPlugin")]
#endif
    private static extern void HapMovieResetFromUnity();

#if UNITY_IPHONE && !UNITY_EDITOR
	[DllImport ("__Internal")]
#else
    [DllImport("UnityHapPlayerPlugin")]
#endif
    private static extern bool HapMovieGetResolutionFromUnity(ref int width, ref int height);

#if UNITY_IPHONE && !UNITY_EDITOR
	[DllImport ("__Internal")]
#else
    [DllImport("UnityHapPlayerPlugin")]
#endif
    private static extern void HapMovieSetLoopFromUnity(bool isLoop, bool isPalindrome);

#if UNITY_IPHONE && !UNITY_EDITOR
	[DllImport ("__Internal")]
#else
    [DllImport("UnityHapPlayerPlugin")]
#endif
    private static extern void HapMovieSetVolumeFromUnity(float volume);

#if UNITY_IPHONE && !UNITY_EDITOR
	[DllImport ("__Internal")]
#else
    [DllImport("UnityHapPlayerPlugin")]
#endif
    private static extern void HapMoviePlayFromUnity();

#if UNITY_IPHONE && !UNITY_EDITOR
	[DllImport ("__Internal")]
#else
    [DllImport("UnityHapPlayerPlugin")]
#endif
    private static extern void HapMovieSeekToFrameFromUnity(int frame);

    // We'll also pass native pointer to a texture in Unity.
    // The plugin will fill texture data from native code.
#if UNITY_IPHONE && !UNITY_EDITOR
	[DllImport ("__Internal")]
#else
    [DllImport("UnityHapPlayerPlugin")]
#endif
//#if UNITY_GLES_RENDERER
	private static extern void HapMovieSetTextureFromUnity(System.IntPtr texture, int w, int h);
//#else
//    private static extern void HapMovieSetTextureFromUnity(System.IntPtr texture);
//#endif

#if UNITY_IPHONE && !UNITY_EDITOR
	[DllImport ("__Internal")]
#else
    [DllImport("UnityHapPlayerPlugin")]
#endif
    private static extern void SetUnityStreamingAssetsPath([MarshalAs(UnmanagedType.LPStr)] string path);


#if UNITY_IPHONE && !UNITY_EDITOR
	[DllImport ("__Internal")]
#else
    [DllImport("UnityHapPlayerPlugin")]
#endif
    private static extern IntPtr GetRenderEventFunc();

    // A texture for movie update
    private Texture2D mMovieTexture;


    IEnumerator Start()
    {
        Application.targetFrameRate = 30;

        SetUnityStreamingAssetsPath(Application.streamingAssetsPath);

        CreateTextureAndPassToPlugin();
        yield return StartCoroutine("CallPluginAtEndOfFrames");
    }

    delegate Texture2D CreateTextureDelegate(int width, int height, TextureFormat format);

    private void CreateTextureAndPassToPlugin()
    {
        CreateTextureDelegate createTexture = delegate(int width, int height, TextureFormat format)
        {
            // Create a compressed texture
            Texture2D tex = new Texture2D(width, height, format, false /* no mipmaps!!! */)
            {
                // GL_CLAMP_TO_EDGE
                wrapMode = TextureWrapMode.Clamp,
                filterMode = FilterMode.Bilinear
            };
            // TODO: 
            //tex.SetPixels(white);
            
            // Call Apply() so it's actually uploaded to the GPU
            tex.Apply();

            // Set texture onto our matrial
            GetComponent<Renderer>().material.mainTexture = tex;

            return tex;
        };

        // Pass texture pointer to the plugin
        const string path = "C:\\Users\\Lev\\projects\\Interstellar\\Video\\HAP\\Hap Sample Pack One 1080p\\Movies\\Hebopula Hap HD.mov";
        //const string path = "C:\\Users\\Lev\\projects\\Interstellar\\Video\\HAP\\videos\\composition_hap.mov";
        var loaded = HapMovieLoadFromUnity(path);
        if (loaded)
        {
            int width = 0, height = 0;
            HapMovieGetResolutionFromUnity(ref width, ref height);

            mMovieTexture = createTexture(width, height, TextureFormat.DXT1);

            // http://docs.unity3d.com/ScriptReference/Texture.GetNativeTexturePtr.html
            HapMovieSetTextureFromUnity(mMovieTexture.GetNativeTexturePtr(),
                                        mMovieTexture.width, mMovieTexture.height);

            HapMovieSetVolumeFromUnity(0.0f);
            HapMovieSetLoopFromUnity(true, false);
            HapMoviePlayFromUnity();
        }
    }

    public void OnDestroy()
    {
        HapMovieResetFromUnity();
        Destroy(mMovieTexture);
    }

    private IEnumerator CallPluginAtEndOfFrames()
    {
        while (true)
        {
            // Wait until all frame rendering is done
            yield return new WaitForEndOfFrame();

            // Set time for the plugin
            //SetTimeFromUnity(Time.timeSinceLevelLoad);

            // Issue a plugin event with arbitrary integer identifier.
            // The plugin can distinguish between different
            // things it needs to do based on this ID.
            // For our simple plugin, it does not matter which ID we pass here.
            GL.IssuePluginEvent(GetRenderEventFunc(), 1);
        }
    }
}
